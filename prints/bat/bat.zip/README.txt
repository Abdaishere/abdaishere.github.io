A life-size bat on a 30 cm printer
Off the bed, No. 03 - abdaishere.com/prints/bat/

WHAT'S IN THIS ZIP
  bat-handle.stl       Knob + handle, 48 x 48 x 286 mm, prints knob down.
  bat-taper.stl        Taper piece with a keyed spigot, 53.2 x 53.2 x 290 mm,
                        prints wide end down.
  bat-barrel.stl       Barrel with the cupped end, 63.4 x 63.4 x 282 mm,
                        prints joint face down.
  bat-small-parts.stl  One plate: the coupler, the knob's nut holder, the
                        knob cap, the cup plug, and a 4-hole fit-test bar for
                        the rod channel. 165.5 x 72.8 x 44 mm for the plate.

Assembled length is 840 mm (33 in), the three body pieces plus the coupler
threaded onto one M8 rod, which is what holds the bat together end to end.

NAME REMOVED
A friend's name was raised in graffiti-style letters down the barrel on the
printed bat. This STL was regenerated from the CadQuery script with that
text left out of the build entirely (the barrel band is blank from the
source, not a mesh with the letters cut or sanded off), so the barrel here
is a plain cylinder with no lettering and no trace of it. Every other
dimension, including the barrel's size and the lettering band's footprint,
is unchanged.

The real bat's printed barrel ended up in three physical pieces glued back
together, because a tangled filament spool starved two of its prints
partway through. The barrel.stl file here is the single, un-split design the
barrel was meant to print as; it is not a reproduction of that accident.

PRINT SETTINGS (as printed)
  Printer    Creality K1 Max, rooted, Klipper
  Slicer     OrcaSlicer 2.4.2, K1M 0.20 Standard
  Material   PETG, red, 240 C nozzle, bed 75 C for the first layer then 72 C
  Walls      5
  Infill     gyroid: handle 40%, taper 25%, barrel 20%
  Brim       fixed 7 mm, outer only (the slicer's automatic brim grows past
             the printer's purge line otherwise)
  Small-parts plate: first layer 0.24 mm instead of 0.12 (a thin first layer
             tore up on this bed before, see the Panamera post)

HARDWARE (not included, bought separately)
  1x  M8 threaded rod, cut to about 801 mm (the model allows 797-806 mm)
  2x  M8 hex nut, 13 mm spanner size, plus 1 spare for cleaning the cut thread
  2x  M8 washer, 30 mm across, 2 mm thick
  1   medium threadlocker (blue, e.g. Loctite 243) for the cup nut
  1   slow 2-part epoxy, 30 minute or longer working time, for the glued
      joints (not 5-minute epoxy, not superglue)
  1   13 mm deep socket, at least 60 mm long, + ratchet, for the cup nut
  1   small screw, about 3 mm, only to pull the cup plug out later

Push the rod through the loose 8.8 mm channel; short 8.1 mm rings every
~50 mm grip it so it doesn't rattle. A nut and washer clamp each end: one
in a printed holder inside the knob, one under the cup, tightened through
the small parts plate's holder and cap. Full assembly order is in the
original post.

CREDIT AND LICENCE
The bat's profile (the knob, handle, taper and barrel dimensions) was drawn
in CadQuery from typical 33 inch wood-bat turning charts, not copied from
any file. The mechanical idea of running a steel rod through the middle of a
printed bat came from MIHAI_T's "Full size baseball bat" on MakerWorld
(model 2687911); that model's own profile was never published and is not
used here, and the model itself is under MakerWorld's Standard Digital File
License, which does not allow redistributing the file or a derivative of it.
Nothing from that file is included in this download; only the rod idea was
reused, which is not something a licence covers.

The raised-letter name that used to sit on the barrel used the typeface
Sedgwick Ave Display (SIL Open Font License 1.1); since the text has been
removed from this build entirely, that font is no longer used anywhere in
this file.

LICENCE
The profile and every printed feature here are Abdallah El Belkasy's own
work, drawn from published bat-turning charts, not copied from MIHAI_T's or
anyone else's file (see above: only the rod-through-the-middle mechanical
idea was reused, and an idea isn't something a licence covers). So no
upstream terms apply and there is nothing to reconcile:

  Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0)
  https://creativecommons.org/licenses/by-nc-sa/4.0/
  Abdallah El Belkasy, abdaishere.com/prints
