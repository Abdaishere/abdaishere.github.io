Three gel blaster parts from phone photos
Off the bed, No. 02 - abdaishere.com/prints/blaster/

WHAT'S IN THIS ZIP
  blaster-trigger.stl         Replacement trigger, 29.1 x 39.4 x 10 mm.
  blaster-magazine-catch.stl  Magazine catch lever with a rebuilt paddle,
                               9.95 x 40.95 x 9.5 mm.
  blaster-battery-caps.stl    A plate of 4 end caps (2 spares) that hold an
                               18650 cell in the stock's channel, no walls
                               along the sides, 96.7 x 19.6 x 7 mm for the
                               plate.

All three were measured by hand from a toy gel blaster with a soft tape
measure and phone photos, no donor model or scan. No third party design was
used anywhere in these three parts, so there is nothing to credit and
nothing blocking sharing them.

PRINT SETTINGS (as printed)
  Printer    Creality K1 Max, rooted, Klipper
  Slicer     OrcaSlicer 2.4.2, K1M profiles

  Trigger:        red PLA, 0.20 mm layers, 100% infill, no supports.
                  Printed as 2 copies in 15 minutes, 5.1 g.
  Magazine catch: red PETG, 0.16 mm layers, 100% infill, no supports,
                  printed lying flat on its broad face so the layers run
                  along the lever, not across it. 11 minutes, about 2 g.
  Battery caps:   PLA, standard layers, no supports. 14 minutes, 5.46 g
                  for the 4-cap plate.

FIT NOTE
These were fitted to one specific toy blaster of unknown brand and model, so
exact sizes (the trigger's 2.0 mm plate, the catch's 9.5 mm thickness, the
cap's 19.6 mm diameter) may not match a different gun. Treat them as a
starting point and compare against your own part before printing at full
scale.

LICENCE
All three parts are Abdallah El Belkasy's own work (measured and drawn from
scratch, no donor model), so no upstream terms apply and there is nothing to
reconcile:

  Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0)
  https://creativecommons.org/licenses/by-nc-sa/4.0/
  Abdallah El Belkasy, abdaishere.com/prints
