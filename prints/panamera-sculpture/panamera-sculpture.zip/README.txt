A Panamera in 44 slices
Off the bed, No. 01 - abdaishere.com/prints/panamera-sculpture/

WHAT THIS IS
panamera-sculpture.stl: a Porsche Panamera GTS (970) cut into 44 thin slices
standing on a red octagonal plaque, 200 x 110 x 46 mm. From the side the gaps
between the slices close up and the car reads whole.

Two things were taken out of the file at the source, not edited out of the
mesh afterwards: the sculpture was regenerated from its CadQuery script with
the signature and the number plate left out of the build entirely.
  - A name that was engraved on the plaque: that corner of the plaque is now
    blank.
  - The Dubai-style number plate on the car's tail: that face is now a plain
    smooth panel, no frame and no characters.
Everything else, including the hidden "From Abdallah, 2026" message engraved
under the base, is unchanged from the printed piece. Watertight, same size
(200 x 110 x 45.9-46 mm) as the printed version.

PRINT SETTINGS (as printed)
  Printer        Creality K1 Max, rooted, Klipper
  Slicer         OrcaSlicer 2.4.2, profile K1M 0.12 Fine
  Nozzle         0.4 mm, 210 C (215 C first layer)
  Bed            60 C
  Material       PLA, red for the plaque, black for the car and lettering
  Layers         0.12 mm, first layer 0.24 mm
  Walls, infill  3 walls, 15% crosshatch
  Supports       None
  Colour change  Pause at Z 6.12 mm, red out, black in, resume
  Settings changed from the K1M 0.12 Fine defaults:
    first layer height    0.12 -> 0.24 mm
    first layer speed     60 -> 30 mm/s
    first layer infill    105 -> 40 mm/s
    precise outer wall    on -> off (otherwise the 1 mm plaque letters print
                           as single 0.29 mm beads instead of full width)

CREDIT AND LICENCE
This design (the slice geometry, the plaque, the typography, the Dubai-style
plate) is Abdallah El Belkasy's own work, built in CadQuery from the real
970's published dimensions and a side-profile drawing, not from any
downloaded mesh. Two outside sources are credited for inspiration, neither of
which is redistributed here:
  - The idea of a sliced car on a plate came from synysthh's "Porsche Panamera
    GTS, parametric sliced car sculpture" on Cults3D (paid model, private-use
    licence). No file or geometry from that model is included.
  - Early draft versions (not this one) were cut from lnbjfu's "Porsche
    Panamera" print-in-place mesh on MakerWorld (model 3367749), under
    MakerWorld's Standard Digital File License, which does not allow sharing,
    sub-licensing, or redistributing the file or derivatives of it. That mesh
    was dropped before this version: this STL's car shape comes entirely from
    the real car's dimensions and a traced side-view drawing, not from that
    mesh, so nothing of lnbjfu's is in this file.
  - The Nurburgring Nordschleife outline on the plaque is traced from
    OpenStreetMap data (relation 38566), (c) OpenStreetMap contributors,
    licensed ODbL (https://opendatacommons.org/licenses/odbl/). Keep this
    credit line if you reprint or re-share this file.

PANAMERA and GTS are Porsche trademarks. This is a fan piece, not a Porsche
product, and is not for sale.

LICENCE
This file is Abdallah El Belkasy's own work (see above: the car shape, slice
geometry, plaque, and typography are all built from the real car's
dimensions, not from a downloaded mesh), so it carries his own licence,
clean, with no upstream terms to reconcile:

  Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0)
  https://creativecommons.org/licenses/by-nc-sa/4.0/
  Abdallah El Belkasy, abdaishere.com/prints

The one thing this file still owes outward is the Nordschleife track data:
ODbL requires attribution when you publish a "produced work" made from
OpenStreetMap data, which this is, but it does not force a particular
licence on the produced work and does not conflict with CC BY-NC-SA. Keep
the OpenStreetMap credit line above alongside the CC BY-NC-SA line if you
reprint or re-share this file.
